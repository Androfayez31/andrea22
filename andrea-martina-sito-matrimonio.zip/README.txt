SITO MATRIMONIO — ANDREA & MARTINA
=====================================

File principale: index.html

ANTEPRIMA
- Apri index.html in un browser (su iPhone è più semplice dopo averlo pubblicato).
- La pagina è responsive e pensata per telefoni.

PERSONALIZZAZIONE
- Cerca in index.html i testi “Orario da confermare” e “Luogo e orario da definire” per completare programma e ricevimento.
- Per cambiare data/ora del countdown, modifica la riga:
  const weddingDate = new Date('2027-10-02T16:00:00+02:00');
- Per sostituire i segnaposto galleria con fotografie vere, puoi aggiungere immagini e modificare i blocchi <div class="photo"> nella sezione Galleria.

PUBBLICAZIONE GRATUITA CON GITHUB PAGES
1. Nel repository GitHub, apri Add file → Upload files.
2. Carica index.html (puoi anche caricare questo README facoltativo).
3. Vai in Settings → Pages.
4. In “Build and deployment”, scegli “Deploy from a branch”.
5. Seleziona branch “main” e cartella “/ (root)”, poi Save.
6. Attendi la pubblicazione: GitHub mostrerà l'indirizzo pubblico nella sezione Pages.

NOTA RSVP
Il modulo attuale prepara una email sul dispositivo dell'invitato, ma non archivia le risposte in un database. Per raccogliere tutte le conferme in un elenco condiviso, occorre collegare un servizio di moduli esterno oppure aggiungere un backend. Il sito statico e il suo hosting possono restare gratuiti.

NOTE
- L'orario della cerimonia e il luogo del ricevimento sono ancora da confermare.
- Il link Google Maps usa una ricerca per il nome della chiesa: verifica che il risultato sia quello corretto prima di condividerlo.
